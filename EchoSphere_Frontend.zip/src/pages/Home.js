import React from 'react';

function Home() {
  return (
    <div>
      <h1>Welcome to EchoSphere</h1>
      <p>Raising awareness through interactive learning.</p>
    </div>
  );
}

export default Home;
