import React from 'react';

function Quiz() {
  return (
    <div>
      <h1>Quiz Section</h1>
      <p>Test your knowledge on global issues.</p>
    </div>
  );
}

export default Quiz;
