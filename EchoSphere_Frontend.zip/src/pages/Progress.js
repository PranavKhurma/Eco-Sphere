import React from 'react';

function Progress() {
  return (
    <div>
      <h1>Your Progress</h1>
      <p>Track how much you’ve learned!</p>
    </div>
  );
}

export default Progress;
